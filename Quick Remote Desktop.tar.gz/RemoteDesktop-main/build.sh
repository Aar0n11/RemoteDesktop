#!/bin/bash
set -e
source venv/bin/activate
pyinstaller --onefile --add-data "static:static" --hidden-import "app" --name "QuickRemoteDesktop" run.py
rm app.py
rm -rf static
rm run.py
rm -rf venv
rm -rf __pycache__
rm -rf build
rm QuickRemoteDesktop.spec
mv dist/QuickRemoteDesktop .
rm -rf dist
